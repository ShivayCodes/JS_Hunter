# JS Hunter

🔎 A Python tool to find publicly available JavaScript files, extract exposed API endpoints and secrets. Supports verbose output and basic IDS evasion.

## Features

- Extract `.js` files from a web page
- Find API endpoints
- Detect secrets like AWS keys, JWT, Google API keys
- User-Agent rotation for WAF evasion
- Verbose mode
- Ethical hacking purpose only

## Installation

```bash
git clone https://github.com/yourusername/js-hunter.git
cd js-hunter
pip install -r requirements.txt
```

## Usage

```bash
python3 js_hunter.py -u https://example.com -o output.txt -v
```

## Disclaimer

This tool is for educational and authorized security testing only.
