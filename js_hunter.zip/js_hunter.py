import requests
import re
import argparse
import random
from urllib.parse import urljoin

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (X11; Linux x86_64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
]

SECRET_PATTERNS = {
    "AWS": r"AKIA[0-9A-Z]{16}",
    "Google API": r"AIza[0-9A-Za-z\-_]{35}",
    "Slack Token": r"xox[baprs]-([0-9a-zA-Z]{10,48})?",
    "JWT": r"eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+"
}

def get_js_links(url, verbose):
    try:
        headers = {'User-Agent': random.choice(USER_AGENTS)}
        res = requests.get(url, headers=headers, timeout=10)
        res.raise_for_status()
        js_links = re.findall(r'<script[^>]+src=["\'](.*?\.js)["\']', res.text)
        full_links = [urljoin(url, link) for link in js_links]
        if verbose:
            print(f"[+] Found JS files: {len(full_links)}")
        return full_links
    except Exception as e:
        print(f"[-] Error fetching JS files: {e}")
        return []

def scan_js(js_url, verbose):
    try:
        headers = {'User-Agent': random.choice(USER_AGENTS)}
        res = requests.get(js_url, headers=headers, timeout=10)
        res.raise_for_status()
        content = res.text
        apis = re.findall(r'https?://[^\s\'\"",]+', content)
        secrets = []
        for name, pattern in SECRET_PATTERNS.items():
            matches = re.findall(pattern, content)
            if matches:
                secrets.append((name, matches))
        if verbose:
            print(f"[+] Scanned: {js_url} | APIs found: {len(apis)} | Secrets: {len(secrets)}")
        return {'url': js_url, 'apis': apis, 'secrets': secrets}
    except Exception as e:
        if verbose:
            print(f"[-] Failed to scan {js_url}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="JavaScript Endpoint and Secret Finder (Ethical Use)")
    parser.add_argument("-u", "--url", required=True, help="Target base URL")
    parser.add_argument("-o", "--output", required=True, help="Output file name")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose mode")
    args = parser.parse_args()
    base_url = args.url
    out_file = args.output
    verbose = args.verbose
    js_links = get_js_links(base_url, verbose)
    with open(out_file, "w") as f:
        for js in js_links:
            result = scan_js(js, verbose)
            if result:
                f.write(f"\n[+] JS File: {result['url']}\n")
                if result['apis']:
                    f.write("  APIs:\n")
                    for api in result['apis']:
                        f.write(f"    {api}\n")
                if result['secrets']:
                    f.write("  Secrets:\n")
                    for name, matches in result['secrets']:
                        for match in matches:
                            f.write(f"    {name}: {match}\n")
    print(f"[✔] Results saved to '{out_file}'")

if __name__ == "__main__":
    main()
